package servicios;

import java.io.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Function;
import model.CSVSerializable;

public class RegistroHawkins<T extends CSVSerializable & Comparable<T>> {

    private List<T> lista = new ArrayList<>();

    public void agregar(T elem) { lista.add(elem); }
    public T obtener(int i) { return lista.get(i); }
    public void eliminar(int i) { lista.remove(i); }

    public List<T> filtrar(Predicate<T> p) {
        List<T> out = new ArrayList<>();
        for (T e : lista) if (p.test(e)) out.add(e);
        return out;
    }

    public void ordenar() { Collections.sort(lista); }
    public void ordenar(Comparator<T> c) { lista.sort(c); }

    public void paraCadaElemento(Consumer<T> c) { lista.forEach(c); }

    // BINARIO
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
            oos.writeObject(lista);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
            lista = (List<T>) ois.readObject();
        }
    }

    // CSV
    public void guardarEnCSV(String ruta) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {
            for (T e : lista) pw.println(e.toCSV());
        }
    }

    public void cargarDesdeCSV(String ruta, Function<String, T> mapper) throws IOException {
        lista.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            String linea;
            while ((linea = br.readLine()) != null)
                lista.add(mapper.apply(linea));
        }
    }
}
