
package model;

public class CasoHawkins implements CSVSerializable, Comparable<CasoHawkins> {

    private int id;
    private String titulo;
    private String investigador;
    private ClasificacionCaso clasificacion;

    public CasoHawkins(int id, String titulo, String investigador, ClasificacionCaso clasificacion) {
        this.id = id;
        this.titulo = titulo;
        this.investigador = investigador;
        this.clasificacion = clasificacion;
    }

    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public String getInvestigador() { return investigador; }
    public ClasificacionCaso getClasificacion() { return clasificacion; }

    @Override
    public int compareTo(CasoHawkins o) {
        return Integer.compare(this.id, o.id);
    }

    @Override
    public String toString() {
        return String.format(
            "Caso{id=%d, titulo='%s', investigador='%s', clasificacion=%s}",
             id, titulo, investigador, clasificacion
        );
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + investigador + "," + clasificacion;
    }

    public static CasoHawkins fromCSV(String linea) {
        String[] p = linea.split(",");
        int id = Integer.parseInt(p[0].trim());
        String titulo = p[1].trim();
        String investigador = p[2].trim();
        ClasificacionCaso c = ClasificacionCaso.valueOf(p[3].trim());
        return new CasoHawkins(id, titulo, investigador, c);
    }
}
