
package romeroyesicaromina.p2.pkg322;



import model.CasoHawkins;
import model.ClasificacionCaso;
import servicios.RegistroHawkins;
import config.RutasArchivos;
import java.io.IOException;

public class RomeroYesicaRominaP2322 {

  
    public static void main(String[] args) {
        try { 
            RegistroHawkins<CasoHawkins> registro = new RegistroHawkins<>(); 
 
            registro.agregar(new CasoHawkins(1, "Apertura cerca del laboratorio", "Dr. Brenner", ClasificacionCaso.APERTURA_DIMENSIONAL)); 
            registro.agregar(new CasoHawkins(2, "Actividad psíquica elevada", "Dr. Owens", ClasificacionCaso.SUJETO_PSIQUICO)); 
            registro.agregar(new CasoHawkins(3, "Rastros de entidad en Hawkins", "Jim Hopper", ClasificacionCaso.ENTIDAD_HOSTIL)); 
            registro.agregar(new CasoHawkins(4, "Señales electromagnéticas inusuales", "Nancy Wheeler", ClasificacionCaso.FENOMENO_ELECTROMAGNETICO)); 
            registro.agregar(new CasoHawkins(5, "Desaparición de joven en bosque", "Joyce Byers", ClasificacionCaso.DESAPARICION)); 
 
            System.out.println("Casos registrados:"); 
            registro.paraCadaElemento(c -> System.out.println(c)); 
 
            System.out.println("\nCasos tipo SUJETO_PSIQUICO:"); 
            registro.filtrar(c -> c.getClasificacion() == ClasificacionCaso.SUJETO_PSIQUICO).forEach(c -> System.out.println(c)); 
 
            System.out.println("\nCasos que contienen 'portal':"); 
            registro.filtrar(c -> c.getTitulo().toLowerCase().contains("portal")) 
                    .forEach(c -> System.out.println(c)); 
 
            System.out.println("\nCasos ordenados por ID:"); 
            registro.ordenar((c1, c2) -> c1.compareTo(c2)); 
            registro.paraCadaElemento(c -> System.out.println(c)); 
 
            System.out.println("\nCasos ordenados por título:"); 
            registro.ordenar((a, b) -> a.getTitulo().compareToIgnoreCase(b.getTitulo())); 
 
            registro.guardarEnArchivo(RutasArchivos.getRutaBINString()); 
 
            RegistroHawkins<CasoHawkins> cargado = new RegistroHawkins<>(); 
            cargado.cargarDesdeArchivo(RutasArchivos.getRutaBINString()); 
 
            System.out.println("\nCasos cargados desde archivo binario:"); 
            cargado.paraCadaElemento((c -> System.out.println(c))); 
 
            registro.guardarEnCSV(RutasArchivos.getRutaCSVString()); 
 
           cargado.cargarDesdeCSV(RutasArchivos.getRutaCSVString(),linea -> CasoHawkins.fromCSV(linea)); 
 
            System.out.println("\nCasos cargados desde archivo CSV:"); 
            cargado.paraCadaElemento((c -> System.out.println(c))); 
 
        } catch (IOException | ClassNotFoundException e) { 
            System.err.println("Error: " + e.getMessage()); 
        }
    }
    
}
